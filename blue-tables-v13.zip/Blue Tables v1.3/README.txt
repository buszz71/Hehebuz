Thank you for downloading BlueTables! <3

Download the BlueTables zip file, extract it, then drag and drop the bluetables.blueprint into the var/www/pterodactyl directory. 

After you have run that command:
"blueprint -i bluetables"
- Then the panel will automatically build in the changes you have installed.

If you already have Nebula, the colour of the table will go off the the secondary page colour you have set in the nebula designer. 
- When you change this, run the command yarn build:production for your changes to appear on your panel, you may also have to run export NODE_OPTIONS=--openssl-legacy-provider before building the panel. 

If you wish to remove bluetables from your panel run:
- blueprint -r bluetables

If you have any issues please dm me on discord:
- tyler8x
